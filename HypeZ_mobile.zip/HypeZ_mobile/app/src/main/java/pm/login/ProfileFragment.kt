package pm.login.ui.profile

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import pm.login.MainActivity
import pm.login.databinding.ActivityProfileFragmentBinding

class ProfileFragment : Fragment() {

    private var _binding: ActivityProfileFragmentBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = ActivityProfileFragmentBinding.inflate(inflater, container, false)

        // Configurar o clique do botão de logout
        binding.logoutButton.setOnClickListener {
            logout()
        }

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun logout() {
        // Limpar as preferências compartilhadas que guardam o estado de login
        val sharedPref = requireActivity().getSharedPreferences("pmLogin", Context.MODE_PRIVATE)
        sharedPref.edit().putBoolean("login", false).apply()

        // Redirecionar o usuário para a tela de login
        val intent = Intent(activity, MainActivity::class.java)
        startActivity(intent)
        requireActivity().finish() // Finaliza a atividade atual
    }
}

